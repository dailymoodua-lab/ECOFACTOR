export interface CarModel {
  name: string;
  brand: string;
  type: 'ev' | 'hybrid';
  buyPrice: number;
  sellPrice: number;
  battery?: number;
  engine?: number;
  segment: string;
  logistics: number;
  tax: number;
  totalCost: number;
  margin: number;
  marginPercent: number;
}

const LOGISTICS_PER_CAR = 1300;

function calcEV(buy: number, log: number, battery: number) {
  const nds = (buy + log) * 0.2;
  const excise = battery;
  const tax = Math.round(nds + excise);
  return { tax, total: buy + log + tax };
}

function calcHybrid(buy: number, log: number) {
  const duty = (buy + log) * 0.1;
  const nds = (buy + log + duty) * 0.2;
  const tax = Math.round(nds + duty);
  return { tax, total: buy + log + tax };
}

function makeCar(raw: Omit<CarModel, 'logistics' | 'tax' | 'totalCost' | 'margin' | 'marginPercent'>): CarModel {
  const log = LOGISTICS_PER_CAR;
  const { tax, total } = raw.type === 'ev'
    ? calcEV(raw.buyPrice, log, raw.battery || 0)
    : calcHybrid(raw.buyPrice, log);
  const margin = raw.sellPrice - total;
  return { ...raw, logistics: log, tax, totalCost: total, margin, marginPercent: Math.round((margin / raw.sellPrice) * 100) };
}

export const evCars: CarModel[] = [
  makeCar({ name: 'BYD Seagull', brand: 'BYD', type: 'ev', buyPrice: 9500, sellPrice: 15500, battery: 38, segment: 'A-class' }),
  makeCar({ name: 'BYD Dolphin', brand: 'BYD', type: 'ev', buyPrice: 14000, sellPrice: 22500, battery: 44, segment: 'B-class' }),
  makeCar({ name: 'BYD Yuan Up', brand: 'BYD', type: 'ev', buyPrice: 12000, sellPrice: 19500, battery: 50, segment: 'B-SUV' }),
  makeCar({ name: 'Xiaomi SU7', brand: 'Xiaomi', type: 'ev', buyPrice: 22000, sellPrice: 35000, battery: 73, segment: 'D-sedan' }),
  makeCar({ name: 'Zeekr 001', brand: 'Zeekr', type: 'ev', buyPrice: 28000, sellPrice: 45000, battery: 100, segment: 'E-class' }),
];

export const hybridCars: CarModel[] = [
  makeCar({ name: 'BYD Song Plus DM-i', brand: 'BYD', type: 'hybrid', buyPrice: 16000, sellPrice: 26500, engine: 1.5, segment: 'C-SUV' }),
  makeCar({ name: 'Lixiang L6', brand: 'Lixiang', type: 'hybrid', buyPrice: 25000, sellPrice: 40000, engine: 1.5, segment: 'D-SUV' }),
  makeCar({ name: 'AITO M7', brand: 'Huawei/AITO', type: 'hybrid', buyPrice: 28000, sellPrice: 44000, engine: 1.5, segment: 'D-SUV' }),
];

export const allCars = [...evCars, ...hybridCars];

export const CONTAINER = { cost: 3500, cars: 3, perCar: Math.round(3500 / 3) };

export const TRANSIT = [
  { stage: 'Китай (подготовка)', days: [5, 10], color: '#3B82F6' },
  { stage: 'Порт отгрузки', days: [7, 12], color: '#8B5CF6' },
  { stage: 'Морская перевозка', days: [30, 40], color: '#0EA5E9' },
  { stage: 'ЕС (таможня + доставка)', days: [5, 10], color: '#10B981' },
];

export const CAPITAL_ALLOCATION = [
  { name: 'Машины в обороте', value: 65, color: '#3B82F6' },
  { name: 'Машины в пути', value: 15, color: '#8B5CF6' },
  { name: 'Тест-драйв парк', value: 10, color: '#0EA5E9' },
  { name: 'Быстрый склад', value: 5, color: '#10B981' },
  { name: 'Резерв', value: 5, color: '#F59E0B' },
];

export const slideNames = [
  'Обложка', 'Суть проекта', 'Почему это работает', 'Рынок 2026', 'География запуска',
  'Что финансируется', 'Капитал $3M', 'Логика склада', 'Логистика', 'Разбивка сроков',
  'Контейнерная модель', 'Стоимость логистики', 'Реальная стоимость/авто', 'Налоги EV', 'Налоги Hybrid',
  'Ядро ассортимента', 'Все EV', 'Все Hybrid',
  'UE: Seagull', 'UE: Dolphin', 'UE: SU7', 'UE: Song Plus', 'UE: L6', 'UE: M7',
  'Самые ликвидные', 'Самые маржинальные',
  'Тест-драйв стратегия', 'Быстрый склад', 'Pipeline машин', 'Пример партии',
  'Структура капитала', 'Финмодель', 'ROI', 'Доход инвестора',
  'Масштабирование', 'Exit стратегия', 'Итог',
];
