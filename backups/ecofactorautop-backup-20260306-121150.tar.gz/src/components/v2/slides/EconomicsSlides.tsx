import { motion } from 'framer-motion';
import { BarChart, Bar, XAxis, YAxis, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import { SlideWrapper } from '../SlideWrapper';
import { FadeIn, AnimatedCounter, GlassCard, SlideLabel, SlideTitle, AnimatedBar } from '../AnimatedComponents';
import { evCars, hybridCars, allCars, type CarModel } from '@/data/presentationData';

/* ── UNIT ECONOMICS TEMPLATE ── */
const UESlide = ({ car }: { car: CarModel }) => {
  const data = [
    { name: 'Закупка', value: car.buyPrice, color: '#3B82F6' },
    { name: 'Логистика', value: car.logistics, color: '#8B5CF6' },
    { name: 'Налоги', value: car.tax, color: '#F59E0B' },
  ];

  return (
    <SlideWrapper>
      <FadeIn><SlideLabel>Unit Economics</SlideLabel></FadeIn>
      <FadeIn delay={0.1}><SlideTitle>{car.name}</SlideTitle></FadeIn>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
        <FadeIn delay={0.2}>
          <GlassCard className="p-5">
            <p className="text-xs text-pres-gray mb-3">Структура себестоимости</p>
            <div className="h-[180px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={data} layout="vertical" margin={{ left: 10, right: 20 }}>
                  <XAxis type="number" hide />
                  <YAxis type="category" dataKey="name" width={75} tick={{ fontSize: 12, fill: '#64748B' }} />
                  <Tooltip formatter={(v: number) => `$${v.toLocaleString()}`} />
                  <Bar dataKey="value" radius={[0, 8, 8, 0]} animationDuration={1200}>
                    {data.map((d, i) => <Cell key={i} fill={d.color} />)}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </GlassCard>
        </FadeIn>
        <FadeIn delay={0.3}>
          <div className="space-y-3">
            <GlassCard className="p-4">
              <p className="text-xs text-pres-gray">Себестоимость</p>
              <p className="text-2xl font-bold text-pres-dark">$<AnimatedCounter target={car.totalCost} /></p>
            </GlassCard>
            <GlassCard className="p-4">
              <p className="text-xs text-pres-gray">Цена продажи</p>
              <p className="text-2xl font-bold text-pres-teal">$<AnimatedCounter target={car.sellPrice} /></p>
            </GlassCard>
            <GlassCard className="p-4" style={{ borderLeft: '3px solid hsl(37 92% 55%)' }}>
              <p className="text-xs text-pres-gray">Маржа</p>
              <p className="text-xl font-bold text-pres-gold">
                $<AnimatedCounter target={car.margin} /> <span className="text-sm">({car.marginPercent}%)</span>
              </p>
            </GlassCard>
          </div>
        </FadeIn>
      </div>
    </SlideWrapper>
  );
};

/* ── 19-24: UNIT ECONOMICS ── */
export const UE_Seagull = () => <UESlide car={evCars[0]} />;
export const UE_Dolphin = () => <UESlide car={evCars[1]} />;
export const UE_SU7 = () => <UESlide car={evCars[3]} />;
export const UE_SongPlus = () => <UESlide car={hybridCars[0]} />;
export const UE_L6 = () => <UESlide car={hybridCars[1]} />;
export const UE_M7 = () => <UESlide car={hybridCars[2]} />;

/* ── 25: MOST LIQUID ── */
export const MostLiquidSlide = () => {
  const ranked = [...allCars].sort((a, b) => a.sellPrice - b.sellPrice);
  return (
    <SlideWrapper>
      <FadeIn><SlideLabel>Рейтинг</SlideLabel></FadeIn>
      <FadeIn delay={0.1}><SlideTitle>Самые ликвидные модели</SlideTitle></FadeIn>
      <FadeIn delay={0.15}><p className="text-sm text-pres-gray mt-2">Ранжирование по доступности цены — чем доступнее, тем быстрее продажа</p></FadeIn>
      <div className="mt-6 space-y-1">
        {ranked.map((c, i) => (
          <FadeIn key={c.name} delay={i * 0.08}>
            <AnimatedBar label={`${i + 1}. ${c.name}`} value={c.sellPrice} max={45000} color={c.type === 'ev' ? '#10B981' : '#3B82F6'} suffix=" $" />
          </FadeIn>
        ))}
      </div>
    </SlideWrapper>
  );
};

/* ── 26: MOST PROFITABLE ── */
export const MostProfitableSlide = () => {
  const ranked = [...allCars].sort((a, b) => b.margin - a.margin);
  return (
    <SlideWrapper>
      <FadeIn><SlideLabel>Рейтинг</SlideLabel></FadeIn>
      <FadeIn delay={0.1}><SlideTitle>Самые маржинальные модели</SlideTitle></FadeIn>
      <div className="mt-6 space-y-1">
        {ranked.map((c, i) => (
          <FadeIn key={c.name} delay={i * 0.08}>
            <AnimatedBar label={`${i + 1}. ${c.name}`} value={c.margin} max={15000} color={c.type === 'ev' ? '#F59E0B' : '#8B5CF6'} suffix={` $ (${c.marginPercent}%)`} />
          </FadeIn>
        ))}
      </div>
    </SlideWrapper>
  );
};

export const economicsSlides = [UE_Seagull, UE_Dolphin, UE_SU7, UE_SongPlus, UE_L6, UE_M7, MostLiquidSlide, MostProfitableSlide];
