import { motion } from 'framer-motion';
import { SlideWrapper } from '../SlideWrapper';
import { FadeIn, AnimatedCounter, GlassCard, SlideLabel, SlideTitle, AnimatedBar } from '../AnimatedComponents';

/* ── SLIDE 1: COVER ── */
export const CoverSlide = () => (
  <SlideWrapper gradient>
    <div className="text-center">
      <FadeIn><SlideLabel>Инвестиционная презентация 2026</SlideLabel></FadeIn>
      <FadeIn delay={0.1}>
        <h1 className="text-3xl md:text-6xl font-extrabold text-pres-dark mt-4 leading-tight">
          Импорт китайских<br /><span className="text-pres-blue">EV и гибридов</span>
        </h1>
      </FadeIn>
      <FadeIn delay={0.25}>
        <p className="text-base md:text-lg text-pres-gray mt-4 max-w-xl mx-auto">
          Инвестиционная модель товарного оборота с доходностью 20–27% годовых
        </p>
      </FadeIn>
      <FadeIn delay={0.4}>
        <div className="flex flex-wrap justify-center gap-4 mt-8">
          <GlassCard className="px-6 py-4 text-center"><p className="text-xs text-pres-gray">ROI</p><p className="text-2xl font-bold text-pres-teal">20–27%</p></GlassCard>
          <GlassCard className="px-6 py-4 text-center"><p className="text-xs text-pres-gray">Капитал</p><p className="text-2xl font-bold text-pres-blue">до $3M</p></GlassCard>
          <GlassCard className="px-6 py-4 text-center"><p className="text-xs text-pres-gray">Цикл оборота</p><p className="text-2xl font-bold text-pres-gold">60–80 дней</p></GlassCard>
        </div>
      </FadeIn>
    </div>
  </SlideWrapper>
);

/* ── SLIDE 2: PROJECT ESSENCE ── */
const flowSteps = ['Инвестор', 'Закупка', 'Логистика', 'Склад', 'Продажа', 'Прибыль'];
const flowIcons = ['💰', '🏭', '🚢', '📦', '🤝', '📈'];

export const EssenceSlide = () => (
  <SlideWrapper>
    <FadeIn><SlideLabel>Как это работает</SlideLabel></FadeIn>
    <FadeIn delay={0.1}><SlideTitle>Суть проекта</SlideTitle></FadeIn>
    <div className="mt-8 flex flex-wrap justify-center gap-2 md:gap-0">
      {flowSteps.map((step, i) => (
        <motion.div
          key={step}
          initial={{ opacity: 0, scale: 0.8 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ delay: i * 0.15, duration: 0.5 }}
          className="flex items-center"
        >
          <GlassCard className="px-4 py-4 md:px-6 md:py-5 text-center min-w-[100px]">
            <div className="text-2xl mb-1">{flowIcons[i]}</div>
            <p className="text-sm font-semibold text-pres-dark">{step}</p>
          </GlassCard>
          {i < flowSteps.length - 1 && (
            <motion.div
              initial={{ opacity: 0, scaleX: 0 }}
              whileInView={{ opacity: 1, scaleX: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.15 + 0.1, duration: 0.3 }}
              className="hidden md:block w-8 h-0.5 bg-pres-blue/30 mx-1"
            />
          )}
        </motion.div>
      ))}
    </div>
    <FadeIn delay={0.9}>
      <p className="text-center text-sm text-pres-gray mt-6">Капитал оборачивается каждые 60–80 дней, генерируя стабильную прибыль</p>
    </FadeIn>
  </SlideWrapper>
);

/* ── SLIDE 3: WHY WORKS ── */
export const WhyWorksSlide = () => (
  <SlideWrapper>
    <FadeIn><SlideLabel>Рыночный контекст</SlideLabel></FadeIn>
    <FadeIn delay={0.1}><SlideTitle>Почему эта модель работает</SlideTitle></FadeIn>
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8">
      {[
        { label: 'Рост EV рынка в ЕС, %', value: 37, suffix: '%', color: 'text-pres-blue' },
        { label: 'Доля китайских EV, %', value: 25, suffix: '%', color: 'text-pres-teal' },
        { label: 'Экономия vs европейские', value: 40, suffix: '%', color: 'text-pres-gold' },
        { label: 'Спрос на доступные EV', value: 92, suffix: '%', color: 'text-pres-blue' },
      ].map((m, i) => (
        <FadeIn key={m.label} delay={i * 0.12}>
          <GlassCard className="p-5 text-center">
            <p className={`text-3xl md:text-4xl font-extrabold ${m.color}`}>
              <AnimatedCounter target={m.value} suffix={m.suffix} />
            </p>
            <p className="text-xs text-pres-gray mt-2">{m.label}</p>
          </GlassCard>
        </FadeIn>
      ))}
    </div>
  </SlideWrapper>
);

/* ── SLIDE 4: MARKET 2026 ── */
export const Market2026Slide = () => (
  <SlideWrapper>
    <FadeIn><SlideLabel>Регуляция</SlideLabel></FadeIn>
    <FadeIn delay={0.1}><SlideTitle>Рынок 2026: налоговая среда</SlideTitle></FadeIn>
    <div className="mt-8 space-y-1">
      <AnimatedBar label="НДС (все авто)" value={20} max={25} color="#3B82F6" suffix="%" />
      <AnimatedBar label="Пошлина EV" value={0} max={25} color="#10B981" suffix="%" />
      <AnimatedBar label="Акциз EV" value={1} max={25} color="#0EA5E9" suffix=" €/kWh" />
      <AnimatedBar label="Пошлина гибриды" value={10} max={25} color="#8B5CF6" suffix="%" />
    </div>
    <FadeIn delay={0.5}>
      <GlassCard className="p-4 mt-6">
        <p className="text-sm text-pres-gray">💡 EV имеют <span className="font-bold text-pres-teal">нулевую пошлину</span> — это ключевое преимущество перед гибридами и ДВС</p>
      </GlassCard>
    </FadeIn>
  </SlideWrapper>
);

/* ── SLIDE 5: GEOGRAPHY ── */
const phases = [
  { phase: 'Фаза 1', region: 'Украина', desc: 'Запуск, тестирование спроса', color: '#3B82F6', scale: 1 },
  { phase: 'Фаза 2', region: 'Польша + Восточная Европа', desc: 'Масштабирование', color: '#8B5CF6', scale: 1.2 },
  { phase: 'Фаза 3', region: 'Расширение по ЕС', desc: 'Полное покрытие', color: '#10B981', scale: 1.5 },
];

export const GeographySlide = () => (
  <SlideWrapper>
    <FadeIn><SlideLabel>Стратегия расширения</SlideLabel></FadeIn>
    <FadeIn delay={0.1}><SlideTitle>География запуска</SlideTitle></FadeIn>
    <div className="mt-8 flex flex-col md:flex-row gap-4 items-center md:items-end justify-center">
      {phases.map((p, i) => (
        <motion.div
          key={p.phase}
          initial={{ opacity: 0, y: 30, scale: 0.9 }}
          whileInView={{ opacity: 1, y: 0, scale: 1 }}
          viewport={{ once: true }}
          transition={{ delay: i * 0.2, duration: 0.5 }}
          className="flex-1 w-full max-w-xs"
        >
          <GlassCard className="p-5 text-center relative overflow-hidden">
            <div className="absolute inset-0 opacity-5" style={{ background: p.color }} />
            <div className="w-12 h-12 rounded-full mx-auto mb-3 flex items-center justify-center text-lg font-bold" style={{ background: `${p.color}20`, color: p.color }}>
              {i + 1}
            </div>
            <p className="font-bold text-pres-dark text-lg">{p.region}</p>
            <p className="text-xs text-pres-gray mt-1">{p.desc}</p>
            <p className="text-xs font-medium mt-2" style={{ color: p.color }}>{p.phase}</p>
          </GlassCard>
        </motion.div>
      ))}
    </div>
  </SlideWrapper>
);

export const introSlides = [CoverSlide, EssenceSlide, WhyWorksSlide, Market2026Slide, GeographySlide];
